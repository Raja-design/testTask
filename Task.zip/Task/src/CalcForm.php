<?php

namespace raj\PHP;


class CalcForm
{
    function calcRemainder($number,$param )
    {
        return $number % $param;

    }


    function addRemainder($number3,$number5)
    {
        return $number3 +  $number5;
    }

}
